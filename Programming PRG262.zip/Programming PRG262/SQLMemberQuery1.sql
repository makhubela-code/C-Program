USE GYMMEMBERSHIP 
CREATE TABLE membertbl (
MemberID int,
FirstName varchar(255),
lastName varchar(255),	
DOB varchar(255),
Gender varchar(255),
Phoneno int,
Address varchar(255),
TrainingP varchar(255),
MemberSD varchar(255),
MemberED varchar(255)
)
INSERT INTO dbo.membertbl VALUES
(25,'Keketso', 'Miya', '2002/06/08', 'Male', 0785963258,'721 Margaret', 'physio','25May2024', '06July2024')
SELECT * FROM dbo.membertbl