CREATE DATABASE GYMMEMBERSHIP
USE GYMMEMBERSHIP
CREATE TABLE programtbl (
ProgramID int,
ProgramName varchar(255),
Description varchar(255),
Instructor varchar(255),
Schedule varchar(255),
Capacity int,
Duration varchar(255)
)
INSERT INTO dbo.programtbl VALUES
(11,'JUMPING','EAT HEALTHY', 'Yolanda', 'Morning',8,'2 Hours') 
SELECT * FROM dbo.programtbl

