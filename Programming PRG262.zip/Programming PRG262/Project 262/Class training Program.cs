﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_262
{
    internal class Class_training_Program
    {
        public int programId {  get; set; }
        public string programName { get; set; }
        public string Description { get; set; }
        public string Instructor { get; set; }
        public string Schedule { get; set; }
        public int Capacity { get; set; }
        public string Duration  { get; set; }
         public Class_training_Program() { }

        public Class_training_Program(int programId, string programName, string description, string instructor, string schedule, int capacity, string duration)
        {
            this.programId = programId;
            this.programName = programName;
            Description = description;
            Instructor = instructor;
            Schedule = schedule;
            Capacity = capacity;
            Duration = duration;
        }

    }

}
