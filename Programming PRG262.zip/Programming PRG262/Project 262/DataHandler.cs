﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_262
{
    internal class DataHandler
    {


        static string connect = "Data Source=BROMMUNITY; Initial Catalog = GYMMEMBERSHIP; Integrated Security = SSPI;";

        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter adapt;

        public void RegisterProgram(int id, string name, string description, string Instructor, string Schedule, int Capacity, string Duration)
        {
            string query = $"Insert into dbo.programtbl Values ('{id}','{name}', '{description}', '{Instructor}', '{Schedule}','{Capacity}', '{Duration}')";

            con = new SqlConnection(connect);

            con.Open();

            cmd = new SqlCommand(query, con);

            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Program registered");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to register " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        public void UpdateProgram(int id, string name, string description, string Instructor, string Schedule, int Capacity, string Duration)
        {
            string query = $"UPDATE programtbl SET [ProgramID] ='{id}',[ProgramName] ='{name}',[Description]='{description}',[Instructor]='{Instructor}',[Schedule]='{Schedule}',[Capacity]='{Capacity}',[Duration]='{Duration}'";

            con = new SqlConnection(connect);
            con.Open();

            cmd = new SqlCommand(query, con);

            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Program Updated");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to Update " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        public void DeleteProgram(int id)
        {
            string query = $"Delete FROM programtbl WHERE ProgramID = '{id}'";

            con = new SqlConnection(connect);

            con.Open(); cmd = new SqlCommand(query, con);

            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Program details deleted");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to delete member details" + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        public void RegisterMember(int id, string fname, string lname, string dateofBirth, string gender, int Phoneno, string Address, string Tp, string MemberSD, string MemberED)
        {
            string query = $"Insert into dbo.membertbl Values ('{id}','{fname}', '{lname}', '{dateofBirth}', '{gender}','{Phoneno}', '{Address}','{Tp}','{MemberSD}','{MemberED}')";

            con = new SqlConnection(connect);

            con.Open();

            cmd = new SqlCommand(query, con);

            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Member registered");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to register " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        public void UpdateMember(int id, string fname, string lname, string DOB, string Gender, int Phoneno, string Tp, string MemberST, string MemberED)
        {
            string query = $"UPDATE membertbl SET [MemberID] ='{id}',[FirstName] ='{fname}',[LastName]='{lname}',[DateofBirth]='{DOB}',[Gender]='{Gender}',[Phoneno]='{Phoneno}',[TrainingProgramming]='{Tp}','[MemberStart]='{MemberST}','[MemberEnd]='{MemberED}'";

            con = new SqlConnection(connect);
            con.Open();

            cmd = new SqlCommand(query, con);

            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Member Updated");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to Update " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        public void DeleteMember(int id)
        {
            string query = $"Delete FROM membertbl WHERE MemberID = '{id}'";

            con = new SqlConnection(connect);

            con.Open(); cmd = new SqlCommand(query, con);

            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("member details deleted");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to delete member details" + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }
    }
}
       
