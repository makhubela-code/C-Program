﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_262
{
    public partial class Member_Info : Form
    {
        public Member_Info()
        {
            InitializeComponent();
        }
        DataHandler handler = new DataHandler();
        BindingSource src = new BindingSource();
        Memberrr member = new Memberrr();
        private void btnRegister_Click(object sender, EventArgs e)
        {
            member.MemberID = int.Parse(txtMemberID.Text);
            member.FName = txtFirstName.Text;
            member.LName = txtLastName.Text;
            member.DateofBirth = txtDateofBirth.Text;
            member.Gender = txtGender.Text;
            member.Phonenumber = int.Parse(txtPhoneNumber.Text);
            member.Address = txtTraining.Text;
            member.MemberSt =txtMemberStart.Text;
            member.MemberED = txtMemberEnd.Text;
            handler.RegisterMember(member.MemberID, member.FName, member.LName, member.DateofBirth, member.Gender, member.Phonenumber, member.Address,member.TrainingProgram, member.MemberSt, member.MemberED);

        }

        private void Member_Info_Load(object sender, EventArgs e)
        {

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            member.MemberID = int.Parse(txtMemberID.Text);
            member.FName = txtFirstName.Text;
            member.LName = txtLastName.Text;
            member.DateofBirth = txtDateofBirth.Text;
            member.Gender = txtGender.Text;
            member.Phonenumber = int.Parse(txtPhoneNumber.Text);
            member.Address = txtTraining.Text;
            member.MemberSt = txtMemberStart.Text;
            member.MemberED = txtMemberEnd.Text;
            handler.UpdateMember(member.MemberID, member.FName, member.LName, member.DateofBirth, member.Gender, member.Phonenumber, member.Address, member.MemberSt, member.MemberED);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            member.MemberID = int.Parse(txtMemberID.Text);
            handler.DeleteMember(member.MemberID);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            src.DataSource = member;
            dataGridView1.DataSource = src;

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }
    }
}
