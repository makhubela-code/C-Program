﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_262
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        DataHandler handler = new DataHandler();
        BindingSource src = new BindingSource();
        Class_training_Program classtp = new Class_training_Program();

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            classtp.programId = int.Parse(txtProgramID.Text);
            classtp.programName = txtProgramName.Text;
            classtp.Description = txtDescription.Text;
            classtp.Instructor = txtInstructor.Text;
            classtp.Schedule = txtSchedule.Text;
            classtp.Capacity = int.Parse(txtCapacity.Text);
            classtp.Duration = txtDuration.Text;
            handler.RegisterProgram(classtp.programId, classtp.programName, classtp.Description, classtp.Instructor, classtp.Schedule, classtp.Capacity, classtp.Duration);

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            classtp.programId = int.Parse(txtProgramID.Text);
            classtp.programName = txtProgramName.Text;
            classtp.Description = txtDescription.Text;
            classtp.Instructor = txtInstructor.Text;
            classtp.Schedule = txtSchedule.Text;
            classtp.Capacity = int.Parse(txtCapacity.Text);
            classtp.Duration = txtDuration.Text;
            handler.UpdateProgram(classtp.programId, classtp.programName, classtp.Description, classtp.Instructor, classtp.Schedule, classtp.Capacity, classtp.Duration);

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            classtp.programId = int.Parse(txtProgramID.Text);
            handler.DeleteProgram(classtp.programId);

        }

        private void btnRead_Click(object sender, EventArgs e)
        {
            src.DataSource = classtp;
            dataGridView1.DataSource = src;

        }

        private void btnText_Click(object sender, EventArgs e)
        {
            Member_Info newform = new Member_Info();
            newform.Show();
        }
    }
}
