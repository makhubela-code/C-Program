﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_262
{
    internal class Memberrr
    {
        public int MemberID { get ; set; }
        public string FName { get; set; }
        public string LName { get; set; }
        public string DateofBirth { get; set; }
        public string Gender { get; set; }
        public int Phonenumber { get; set; }
        public string Address { get; set; }
        public string TrainingProgram { get; set; }
        public string MemberSt { get; set; }
        public string MemberED { get; set; }

        public Memberrr () { }

        public Memberrr(int memberID, string fName, string lName, string dateofBirth, string gender, int phonenumber, string address, string trainingProgram, string memberSt, string memberED)
        {
            MemberID = memberID;
            FName = fName;
            LName = lName;
            DateofBirth = dateofBirth;
            Gender = gender;
            Phonenumber = phonenumber;
            Address = address;
            TrainingProgram = trainingProgram;
            MemberSt = memberSt;
            MemberED = memberED;
        }
    }
}
